#include <iostream>

using namespace std;

class Elem {
public:
	int val;
	Elem* next;
	Elem(int num)
	{
		this->val = num;
	}
};

class List {

private:
	Elem* head;
	Elem* tail;
public:
	int buf;

	List(int i)
	{
		this->head = nullptr;
	}

	void add(int index, int num)
	{
		Elem* tmp = this->head;
		int i = 1;
		Elem* el= new Elem(num);
		if (index == 0)		//���� ����� �������� ����� �����
		{
			el->next = this->head;
			this->head = el;
			return;
		}
		if (tmp == nullptr)			//���� c����� ���� 
		{
			cout << "End of list, last element index is " << i << endl;
			return;
		}
		while (i != index )
		{
			if (tmp->next == nullptr)
			{
				cout << "End of list, last element index is" << i << endl;
				return;
			}
			tmp = tmp->next;
			i++;
		}
		if (i == index)				//���� �� ������ �����
		{
			el->next = tmp->next;
			tmp->next = el;
			return;
		}
		if (tmp == nullptr)			//���� �������� ����� ������ 
		{
			cout << "End of list, last element index is " << i << endl;
			return;
		}
	}

	int get(int index)
	{
		Elem* tmp = this->head;
		if (tmp == nullptr)			//���� c����� ���� 
		{
			cout << "List is empty"<< endl;
			return -1;
		}
		int i = 0;
		while (i != index)
		{
			if (tmp->next == nullptr)
			{
				cout << "End of list, last element index is " << i << endl;
				return -1;
			}
			tmp = tmp->next;
			i++;
		}
		if (i == index)				//���� �� ������ �����
		{
			this->buf= tmp->val;
			return 0;
		}
		if (tmp == nullptr)			//���� �������� ����� ������ 
		{
			cout << "End of list, last element index is" << i << endl;
			return -1;
		}
	}

	void del(int index)
	{
		int i = 1;
		Elem* tmp=this->head;
		if (index == 0)
		{
			Elem* toDel = this->head;
			this->head = (this->head)->next;
			delete toDel;
			return;
		}
		while (i != index)
		{
			if (tmp->next == nullptr)
			{
				cout<< "End of list, last element index is " << i << endl;
				return;
			}
			tmp = tmp->next;
			i++;
		}
		Elem* toDel=tmp->next;
		tmp->next = (tmp->next)->next;
		delete toDel;
	}
};



int main()
{
	List l(0);
	char cmd[32];
	while (strcmp(cmd, "q") != 0)
	{
		cin >> cmd;
		if (strcmp(cmd, "add") == 0)
		{
			char num[16];
			char index[16];
			cin >> index;
			cin >> num;
			l.add(atoi(index),atoi(num));
			continue;
		}
		if (strcmp(cmd, "del") == 0)
		{
			char index[16];
			cin >> index;
			l.del(atoi(index));
			continue;
		}
		if (strcmp(cmd, "get") == 0)
		{
			int ret;
			char index[16];
			cin >> index;
			ret=l.get(atoi(index));
			if(ret!=-1)
				cout << l.buf << endl;
		}
	}
	return 0;
}