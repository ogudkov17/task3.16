#include <iostream>

using namespace std;

class Stack
{
private:
	int top;
	int* arr;
public:
	Stack(int top)
	{
		this->top = top;
		arr = new int[top];
	}

	void add(int num)
	{
		int* tmpArr = new int[this->top + 1];
		for (int i = 0; i < this->top; i++)
			tmpArr[i] = this->arr[i];
		tmpArr[this->top] = num;
		delete this->arr;
		this->arr = tmpArr;
		this->top++;
	}

	void get()
	{
		if (this->top != 0)
			cout << this->arr[this->top - 1] << endl;
		else
			cout << "Stack is empty" << endl;
	}

	int del()
	{
		if (this->top == 0)
		{
			return -1;
		}
		int num;
		int* tmpArr = new int[this->top - 1];
		for (int i = 0; i < this->top - 1; i++)
			tmpArr[i] = this->arr[i];
		num = tmpArr[this->top-1];
		delete this->arr;
		this->arr = tmpArr;
		this->top--;
		return 0;
	}

};

int main()
{
	Stack s(0);
	char cmd[32];
	while (strcmp(cmd, "q") != 0)
	{
		cin >> cmd;
		if (strcmp(cmd, "add") == 0)
		{
			int num;
			char str[32];
			cin >> str;
			num = atoi(str);
			s.add(num);
			continue;
		}
		if (strcmp(cmd, "del") == 0)
		{
			s.del();
			continue;
		}
		if (strcmp(cmd, "get") == 0)
		{
			s.get();
		}
	
	}
	return 0;
}

