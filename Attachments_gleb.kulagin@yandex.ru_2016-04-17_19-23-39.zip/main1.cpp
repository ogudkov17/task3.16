#include <iostream>

using namespace std;

class Queue {
private:
	int length;
	int* arr;
public:
	Queue(int num)
	{
		this->length = num;
		this->arr = new int[num];
	}
	void add(int num)
	{
		int* tmpArr = new int[this->length + 1];
		for (int i = 0; i < this->length; i++)
			tmpArr[i] = this->arr[i];
		tmpArr[this->length] = num;
		delete[] this->arr;
		this->arr = tmpArr;
		this->length++;
	}
	void del()
	{
		if (this->length == 0)
			cout << "Queue is empty" << endl;
		else
		{
			int* tmpArr = new int[this->length - 1];
			for (int i = 1; i < this->length; i++)
				tmpArr[i-1] = this->arr[i];
			delete[] this->arr;
			this->arr = tmpArr;
			this->length--;
		}
	}
	void get()
	{
		if (this->length == 0)
			cout << "Queue is empty" << endl;
		else
			cout << this->arr[0] << endl;
	}

};

int main()
{
	Queue q(0);
	char cmd[32];
	while (strcmp(cmd, "q") != 0)
	{
		cin >> cmd;
		if (strcmp(cmd, "add") == 0)
		{
			int num;
			char str[32];
			cin >> str;
			num = atoi(str);
			q.add(num);
			continue;
		}
		if (strcmp(cmd, "del") == 0)
		{
			q.del();
			continue;
		}
		if (strcmp(cmd, "get") == 0)
		{
			q.get();
		}
	}
	return 0;
}